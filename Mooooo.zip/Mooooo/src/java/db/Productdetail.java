/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author moodisne
 */
@Entity
@Table(name = "productdetail")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Productdetail.findAll", query = "SELECT p FROM Productdetail p"),
    @NamedQuery(name = "Productdetail.findByCodeName", query = "SELECT p FROM Productdetail p WHERE p.codeName = :codeName"),
    @NamedQuery(name = "Productdetail.findByBrand", query = "SELECT p FROM Productdetail p WHERE p.brand = :brand"),
    @NamedQuery(name = "Productdetail.findByVersion", query = "SELECT p FROM Productdetail p WHERE p.version = :version"),
    @NamedQuery(name = "Productdetail.findByPrice", query = "SELECT p FROM Productdetail p WHERE p.price = :price")})
public class Productdetail implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "Code_Name")
    private String codeName;
    @Size(max = 40)
    @Column(name = "Brand")
    private String brand;
    @Size(max = 40)
    @Column(name = "Version")
    private String version;
    @Size(max = 40)
    @Column(name = "Price")
    private String price;
    @OneToMany(mappedBy = "codeName")
    private Collection<Deliverdetail> deliverdetailCollection;

    public Productdetail() {
    }

    public Productdetail(String codeName) {
        this.codeName = codeName;
    }

    public String getCodeName() {
        return codeName;
    }

    public void setCodeName(String codeName) {
        this.codeName = codeName;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    @XmlTransient
    public Collection<Deliverdetail> getDeliverdetailCollection() {
        return deliverdetailCollection;
    }

    public void setDeliverdetailCollection(Collection<Deliverdetail> deliverdetailCollection) {
        this.deliverdetailCollection = deliverdetailCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codeName != null ? codeName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Productdetail)) {
            return false;
        }
        Productdetail other = (Productdetail) object;
        if ((this.codeName == null && other.codeName != null) || (this.codeName != null && !this.codeName.equals(other.codeName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db.Productdetail[ codeName=" + codeName + " ]";
    }
    
}
